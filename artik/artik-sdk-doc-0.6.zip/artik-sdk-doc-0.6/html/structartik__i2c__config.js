var structartik__i2c__config =
[
    [ "address", "structartik__i2c__config.html#a29cf7ef5a5e94e45fb26fa0a4b4ff674", null ],
    [ "frequency", "structartik__i2c__config.html#a50206e66c1a877081145c61a11b14d64", null ],
    [ "id", "structartik__i2c__config.html#a5883541f5a3084a79ab63d37bf5e84f4", null ],
    [ "wordsize", "structartik__i2c__config.html#a85a660fafb6bd6e6e319cd5d0dc27072", null ]
];