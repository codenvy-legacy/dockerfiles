var structartik__adc__config =
[
    [ "name", "structartik__adc__config.html#a15825b758c6036e5b5c9ed43f85d6326", null ],
    [ "pin_num", "structartik__adc__config.html#a0390263e26ded71f5ccf68b7cf0ed20e", null ],
    [ "user_data", "structartik__adc__config.html#ac6c9af31f17aec387142a617cd3d99be", null ]
];