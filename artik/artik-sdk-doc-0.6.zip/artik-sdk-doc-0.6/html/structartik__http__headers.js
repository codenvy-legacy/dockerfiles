var structartik__http__headers =
[
    [ "fields", "structartik__http__headers.html#a0c2d00f170a8117fd6dc60145e1765bf", null ],
    [ "num_fields", "structartik__http__headers.html#a86e92735bb142f7ef895af9a39a17753", null ]
];