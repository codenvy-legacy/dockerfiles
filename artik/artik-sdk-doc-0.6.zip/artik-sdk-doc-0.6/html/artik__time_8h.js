var artik__time_8h =
[
    [ "artik_time_t", "structartik__time__t.html", "structartik__time__t" ],
    [ "artik_time_module", "structartik__time__module.html", "structartik__time__module" ],
    [ "ARTIK_TIME_DFORMAT", "artik__time_8h.html#afe984d83e132443d98e7b5167231e5df", null ],
    [ "artik_msecond", "artik__time_8h.html#ad15ff4a0f73629263d1a041e71d74c55", null ],
    [ "artik_time_gmt_t", "artik__time_8h.html#a4b2cd141640d87372a686d4ad299b11b", null ],
    [ "artik_time_handle", "artik__time_8h.html#acbd0029e3bfe510794af6dfd8b1d0cc5", null ],
    [ "artik_time_zone_t", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038", [
      [ "ARTIK_TIME_UTC", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038ae51a3bc163ad484f67a7cfe99d9f2613", null ],
      [ "ARTIK_TIME_GMT1", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038a9d342d22dcc55f75361033e1cf37cfae", null ],
      [ "ARTIK_TIME_GMT2", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038a724b9450143617bd087f3632ca43967d", null ],
      [ "ARTIK_TIME_GMT3", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038a2d791c5b90186dc174be51e4d65d11cc", null ],
      [ "ARTIK_TIME_GMT4", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038a97f40f879f387e50a24270f274f10456", null ],
      [ "ARTIK_TIME_GMT5", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038ad67cd2a32f260f792fdcef6ba683a454", null ],
      [ "ARTIK_TIME_GMT6", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038acc8b9907fa198ef73013eaaede48e665", null ],
      [ "ARTIK_TIME_GMT7", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038a4715c6e862251c1e7b57f8f11cea0b4c", null ],
      [ "ARTIK_TIME_GMT8", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038aa1a29a319e122792f12b000272940d07", null ],
      [ "ARTIK_TIME_GMT9", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038abf66f3ed7756c809f9d41ab073b1dd90", null ],
      [ "ARTIK_TIME_GMT10", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038a6e14ab9b00e640f579c768eef4df3edb", null ],
      [ "ARTIK_TIME_GMT11", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038acfd3001872d81315d1149f48b810befe", null ],
      [ "ARTIK_TIME_GMT12", "artik__time_8h.html#af561a4563abeee02e2d45390164bd038a428681415aa8cda3c51d07e1030a6857", null ]
    ] ],
    [ "time_module", "artik__time_8h.html#a31302677007fa0b917949597d743aad4", null ]
];