var structartik__time__t =
[
    [ "day", "structartik__time__t.html#a094629aa29ce2afa1d64c61662104d79", null ],
    [ "day_of_week", "structartik__time__t.html#a25631a20bc2d16e71263a0af09bf068a", null ],
    [ "hour", "structartik__time__t.html#a24e5c19ea3f120378cc0791249031330", null ],
    [ "minute", "structartik__time__t.html#a957abe8e44c7d340035116e3a881bc68", null ],
    [ "month", "structartik__time__t.html#a7080d6fcd28ac87fe93690c66d7af681", null ],
    [ "msecond", "structartik__time__t.html#a213958ac43e6a2a174732ec439bcf263", null ],
    [ "second", "structartik__time__t.html#a264fe1b7b345b2d761aac6d92b7c52d0", null ],
    [ "year", "structartik__time__t.html#a75cad11955d3e2c2dc61e9d234715009", null ]
];