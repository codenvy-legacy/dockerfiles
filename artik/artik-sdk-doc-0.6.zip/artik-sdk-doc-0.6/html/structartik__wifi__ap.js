var structartik__wifi__ap =
[
    [ "bssid", "structartik__wifi__ap.html#a4af7d378261c8071d48e794d01c70b82", null ],
    [ "encryption_flags", "structartik__wifi__ap.html#aa52d3917d773ec8479452696e70be16e", null ],
    [ "frequency", "structartik__wifi__ap.html#af9704df9687aee951de4e66692bb1118", null ],
    [ "name", "structartik__wifi__ap.html#a1ce58b28db1295d065ce8a7dd3abbddd", null ],
    [ "signal_level", "structartik__wifi__ap.html#a0564b38dcfdd32f5bf885a16296712fb", null ]
];