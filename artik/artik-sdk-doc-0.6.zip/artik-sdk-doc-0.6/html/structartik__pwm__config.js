var structartik__pwm__config =
[
    [ "duty_cycle", "structartik__pwm__config.html#a46892ac1cf1e17d526977581d995cdd0", null ],
    [ "name", "structartik__pwm__config.html#ae86d7fd13cd767ac7f74fdb9b182d58f", null ],
    [ "period", "structartik__pwm__config.html#a8bd7c17b0d8da4df9de91decee62f1ef", null ],
    [ "pin_num", "structartik__pwm__config.html#a385e539efcaeef5b0fa38d8e2286dabc", null ],
    [ "polarity", "structartik__pwm__config.html#aa3083c358d4b097bf27d71d8be4fee5a", null ],
    [ "user_data", "structartik__pwm__config.html#a360ddbee67f8253b8f6f552d9206e210", null ]
];