var structartik__adc__module =
[
    [ "get_value", "structartik__adc__module.html#ac1ea760de3a0a7c486732857a680a4b3", null ],
    [ "release", "structartik__adc__module.html#aae88dd6f63d9a320c8c970615d9b1e31", null ],
    [ "request", "structartik__adc__module.html#a2fbc0f48b5e7a450e2f8ae989f306950", null ]
];