var classartik_1_1_spi =
[
    [ "Spi", "classartik_1_1_spi.html#a9dcc36807a70b3ab31d7f960a20bdbfd", null ],
    [ "~Spi", "classartik_1_1_spi.html#aeba107929c7e9c4d5fd30b2c62eda4ca", null ],
    [ "read", "classartik_1_1_spi.html#aa8bba5b03c0d6347992206cd989cc41a", null ],
    [ "read_write", "classartik_1_1_spi.html#a25b4ae09a933e5e7aa7a7f8875525547", null ],
    [ "release", "classartik_1_1_spi.html#a7427be6fbac397d55ce1bfd0dc3d7386", null ],
    [ "request", "classartik_1_1_spi.html#a4b9f7ba7bd6b4a066ede96ce93cc1f31", null ],
    [ "write", "classartik_1_1_spi.html#adbfcc3312e0d850d5751401242717549", null ]
];