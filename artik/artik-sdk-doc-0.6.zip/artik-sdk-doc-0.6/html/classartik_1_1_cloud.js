var classartik_1_1_cloud =
[
    [ "Cloud", "classartik_1_1_cloud.html#a7b03645e11a514f39e627d842ce2d309", null ],
    [ "~Cloud", "classartik_1_1_cloud.html#a3949b6fc2656aad8e5e0540b27125a2e", null ],
    [ "delete_device_token", "classartik_1_1_cloud.html#aaf139e0bd0280a7812123783e8e5d15b", null ],
    [ "get_current_user_profile", "classartik_1_1_cloud.html#adb07f75c2ab250ac2745a3b86fbc1d0c", null ],
    [ "get_device", "classartik_1_1_cloud.html#a47c9d9099c55bd72d3b6b4104c1a7b48", null ],
    [ "get_device_token", "classartik_1_1_cloud.html#ae5a417150fc8f98de009f301560c6c08", null ],
    [ "get_user_application_properties", "classartik_1_1_cloud.html#a5841eef6c96e81ee546c111a4401a60c", null ],
    [ "get_user_device_types", "classartik_1_1_cloud.html#a3b6a3754dfb2bf367da9c0b33effa5c5", null ],
    [ "get_user_devices", "classartik_1_1_cloud.html#a4fae42aa7367c65a04c93788680c1cf6", null ],
    [ "sdr_complete_registration", "classartik_1_1_cloud.html#a6ab0d957fcd88d335414f1562f8fcf1b", null ],
    [ "sdr_registration_status", "classartik_1_1_cloud.html#a26f3fa63bd37e396db48ec2f05f43b98", null ],
    [ "sdr_start_registration", "classartik_1_1_cloud.html#aed17b4facd29a1909d52d291014cbe09", null ],
    [ "send_action", "classartik_1_1_cloud.html#a3fe1cac6f8e5457ba7bad121d2bf4be6", null ],
    [ "send_message", "classartik_1_1_cloud.html#aec29921ebea97dcbc94eb7d9c2e14773", null ],
    [ "update_device_token", "classartik_1_1_cloud.html#a4ca4738be96fe476b97a6e99997967f1", null ]
];