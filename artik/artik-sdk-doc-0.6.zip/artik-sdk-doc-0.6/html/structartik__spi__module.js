var structartik__spi__module =
[
    [ "read", "structartik__spi__module.html#a57210a743003bb5841e788d95a3be326", null ],
    [ "read_write", "structartik__spi__module.html#a48d232ab4cfd975ea6cc9af78c7540f5", null ],
    [ "release", "structartik__spi__module.html#a5b99dccad8aabff3bd1919926ac737e8", null ],
    [ "request", "structartik__spi__module.html#ab675c5aefe83be402707f1be5d7f5ab2", null ],
    [ "write", "structartik__spi__module.html#a34f2054c1e4a70d2b0e34bb1653204a4", null ]
];