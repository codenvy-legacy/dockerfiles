var structartik__spi__config =
[
    [ "bits_per_word", "structartik__spi__config.html#af1190f588e95af931b7872016f6911a1", null ],
    [ "bus", "structartik__spi__config.html#ae86c1db146fb82f89cf330d546ccacfc", null ],
    [ "cs", "structartik__spi__config.html#a56700c68549e789696a20f0d4f485070", null ],
    [ "max_speed", "structartik__spi__config.html#a2f151071f4a33c82ba1c9fffdbd7cdd2", null ],
    [ "mode", "structartik__spi__config.html#a7ef45bc882a459107765c2de0db56aef", null ]
];