var artik__spi_8h =
[
    [ "artik_spi_config", "structartik__spi__config.html", "structartik__spi__config" ],
    [ "artik_spi_module", "structartik__spi__module.html", "structartik__spi__module" ],
    [ "artik_spi_handle", "artik__spi_8h.html#a98aceb81e5636f0eeaabf1c1708d69a3", null ],
    [ "artik_spi_mode", "artik__spi_8h.html#a27711e022b06cf93c2e20bbfc68d4d5b", [
      [ "SPI_MODE0", "artik__spi_8h.html#a27711e022b06cf93c2e20bbfc68d4d5baacf2eef6aadb9f0de11862660cd9ade6", null ],
      [ "SPI_MODE1", "artik__spi_8h.html#a27711e022b06cf93c2e20bbfc68d4d5babd92ab028fcac05cf2ed27b4838d1590", null ],
      [ "SPI_MODE2", "artik__spi_8h.html#a27711e022b06cf93c2e20bbfc68d4d5ba2607e91fc0c8ae3334284808d7f94cf5", null ],
      [ "SPI_MODE3", "artik__spi_8h.html#a27711e022b06cf93c2e20bbfc68d4d5bad9636eac0759655110aa77dd6c22da6c", null ],
      [ "SPI_MODE_INVALID", "artik__spi_8h.html#a27711e022b06cf93c2e20bbfc68d4d5ba1c2a7b3f838e63a6227f3d8145ba6ffc", null ]
    ] ],
    [ "spi_module", "artik__spi_8h.html#ad72f464ec2234c61900c3b9ecb4976c9", null ]
];