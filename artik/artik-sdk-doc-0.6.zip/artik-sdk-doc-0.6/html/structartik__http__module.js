var structartik__http__module =
[
    [ "del", "structartik__http__module.html#a7f4a1e42448cb05b0180c3422aae3e33", null ],
    [ "get", "structartik__http__module.html#a99bc3c79d1f6197f71cde1175882b535", null ],
    [ "post", "structartik__http__module.html#a6ef90f72b0ff5ece4cdf1bdfa4656c2d", null ],
    [ "put", "structartik__http__module.html#a0ba1aa8f8ac8aac803f52f29dc0a659e", null ],
    [ "websocket_close_stream", "structartik__http__module.html#a357b72ec7c98546ebbce3c0cc6859bbb", null ],
    [ "websocket_open_stream", "structartik__http__module.html#a17786296e9808ede5ac6534d34f53300", null ],
    [ "websocket_process_stream", "structartik__http__module.html#a35eef4a64749d39b335ac76345bbff84", null ],
    [ "websocket_request", "structartik__http__module.html#a6eb00e92c28fb1b28fc34bf4f08b9578", null ],
    [ "websocket_wait_for_connection", "structartik__http__module.html#a580ee48dc7a46bd7093b0fb74ffc8a8e", null ],
    [ "websocket_wait_for_data", "structartik__http__module.html#a0ef24039875959451f13e151f1d3b355", null ],
    [ "websocket_write_stream", "structartik__http__module.html#a3c3b65e5f5e0a949fa88cf60838b686a", null ]
];