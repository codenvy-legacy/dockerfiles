var dir_bfccd401955b95cf8c75461437045ac0 =
[
    [ "cpp", "dir_2b14feef15b26d78fd34311e76d294eb.html", "dir_2b14feef15b26d78fd34311e76d294eb" ],
    [ "platform", "dir_54e9cde3f0eb920985cfdedc73b932ac.html", "dir_54e9cde3f0eb920985cfdedc73b932ac" ],
    [ "artik_adc.h", "artik__adc_8h.html", "artik__adc_8h" ],
    [ "artik_cloud.h", "artik__cloud_8h.html", "artik__cloud_8h" ],
    [ "artik_error.h", "artik__error_8h.html", "artik__error_8h" ],
    [ "artik_gpio.h", "artik__gpio_8h.html", "artik__gpio_8h" ],
    [ "artik_http.h", "artik__http_8h.html", "artik__http_8h" ],
    [ "artik_i2c.h", "artik__i2c_8h.html", "artik__i2c_8h" ],
    [ "artik_media.h", "artik__media_8h.html", "artik__media_8h" ],
    [ "artik_module.h", "artik__module_8h.html", "artik__module_8h" ],
    [ "artik_platform.h", "artik__platform_8h.html", "artik__platform_8h" ],
    [ "artik_pwm.h", "artik__pwm_8h.html", "artik__pwm_8h" ],
    [ "artik_security.h", "artik__security_8h.html", "artik__security_8h" ],
    [ "artik_serial.h", "artik__serial_8h.html", "artik__serial_8h" ],
    [ "artik_spi.h", "artik__spi_8h.html", "artik__spi_8h" ],
    [ "artik_time.h", "artik__time_8h.html", "artik__time_8h" ],
    [ "artik_types.h", "artik__types_8h.html", "artik__types_8h" ],
    [ "artik_wifi.h", "artik__wifi_8h.html", "artik__wifi_8h" ]
];