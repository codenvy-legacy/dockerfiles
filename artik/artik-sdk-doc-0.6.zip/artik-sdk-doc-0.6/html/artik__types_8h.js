var artik__types_8h =
[
    [ "bool", "artik__types_8h.html#af6a258d8f3ee5206d682d799316314b1", [
      [ "false", "artik__types_8h.html#af6a258d8f3ee5206d682d799316314b1ae9de385ef6fe9bf3360d1038396b884c", null ],
      [ "true", "artik__types_8h.html#af6a258d8f3ee5206d682d799316314b1a08f175a5505a10b9ed657defeb050e4b", null ]
    ] ]
];