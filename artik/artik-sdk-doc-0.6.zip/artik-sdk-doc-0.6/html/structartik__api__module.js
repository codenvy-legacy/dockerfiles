var structartik__api__module =
[
    [ "id", "structartik__api__module.html#a220e4179f1c71ae98290e474c2150912", null ],
    [ "name", "structartik__api__module.html#a83fd5352a97b66c12e3e76128fb7f10f", null ],
    [ "ops", "structartik__api__module.html#af30ebd859b83f906bfd0201e9f0301ab", null ]
];