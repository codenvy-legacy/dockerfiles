var structartik__time__module =
[
    [ "cancel_alarm", "structartik__time__module.html#a488e8c3a988d8248e9d4fd3915f3ce25", null ],
    [ "create_alarm_date", "structartik__time__module.html#aeb928b88b023413e5491a9b30739d94f", null ],
    [ "create_alarm_second", "structartik__time__module.html#a13a247b58642f800438f4310e48a35c7", null ],
    [ "delete_alarm", "structartik__time__module.html#ad6d5a6a37692a86cc5a68abe13f9d863", null ],
    [ "get_delay_alarm", "structartik__time__module.html#a44a9231304543c8310a56a1e0968f7ab", null ],
    [ "get_tick", "structartik__time__module.html#aac092364f751c24d293957a41b0d20e1", null ],
    [ "get_time", "structartik__time__module.html#a39421c1d179288b5cfa825e3097a4b56", null ],
    [ "get_time_str", "structartik__time__module.html#a29fec58eeb34aabbcc3984e0c690f4e6", null ],
    [ "set_time", "structartik__time__module.html#a98568d366a5c06a26a2936ef52537e57", null ],
    [ "wait_alarm", "structartik__time__module.html#a3529c51ada9fda8e30fb49c0f4a62722", null ]
];