var structartik__http__header__field =
[
    [ "data", "structartik__http__header__field.html#a38986ea859e4b2024bd68eb353a60a8f", null ],
    [ "name", "structartik__http__header__field.html#ac709d6eec75c6b7748cafe618e77f32c", null ]
];