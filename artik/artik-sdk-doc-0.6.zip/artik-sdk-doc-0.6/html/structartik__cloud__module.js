var structartik__cloud__module =
[
    [ "delete_device_token", "structartik__cloud__module.html#aa75f5feb0700b41c4bca954d25302adc", null ],
    [ "get_current_user_profile", "structartik__cloud__module.html#ae0e8641535afc2408e550e4280f8b3a0", null ],
    [ "get_device", "structartik__cloud__module.html#a3d8cd33755c36c0063139635f110a9d5", null ],
    [ "get_device_token", "structartik__cloud__module.html#a4996c95abb502678fa22358af536a095", null ],
    [ "get_user_application_properties", "structartik__cloud__module.html#aa8d229d3c672670cb5d00cee00ad9357", null ],
    [ "get_user_device_types", "structartik__cloud__module.html#ae0efac9d26eac82e079041c928b6ecc1", null ],
    [ "get_user_devices", "structartik__cloud__module.html#ae73438692f5c5002b21a298a6d713a2a", null ],
    [ "sdr_complete_registration", "structartik__cloud__module.html#a53504024f2d8dcaf4bba0fd66e3d8942", null ],
    [ "sdr_registration_status", "structartik__cloud__module.html#a8413ce02a1baab43ac00899717a2dd36", null ],
    [ "sdr_start_registration", "structartik__cloud__module.html#a9859f81fb8ce1d4b72daf6052b67dcee", null ],
    [ "send_action", "structartik__cloud__module.html#acb1b55c5d2aa6c71a78c26cad9b3b08b", null ],
    [ "send_message", "structartik__cloud__module.html#a0c27f4928e9eef1dd5bcd0f0f70622b8", null ],
    [ "update_device_token", "structartik__cloud__module.html#abe9dc49377aa69af886d85669f127cd5", null ],
    [ "websocket_close_stream", "structartik__cloud__module.html#aedbc0867e65daba1605020ae88d22fbb", null ],
    [ "websocket_open_stream", "structartik__cloud__module.html#adeddca247fcfc7e19ea45605e03fe571", null ],
    [ "websocket_process_stream", "structartik__cloud__module.html#ae19a3209213ae54654a6d6b37b85e6f1", null ],
    [ "websocket_read_action", "structartik__cloud__module.html#a63daba75676a470617e802c8b4a24e89", null ],
    [ "websocket_send_message", "structartik__cloud__module.html#a5dc8747dd420bef33f06a885c213e06e", null ]
];