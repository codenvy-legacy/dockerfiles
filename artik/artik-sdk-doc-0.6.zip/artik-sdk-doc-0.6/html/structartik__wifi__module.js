var structartik__wifi__module =
[
    [ "connect", "structartik__wifi__module.html#a5ec232bfaba35f470708d432580c999e", null ],
    [ "disconnect", "structartik__wifi__module.html#a2c0586a5ce9c5c3881f7a09a65070cb0", null ],
    [ "scan", "structartik__wifi__module.html#a7dc612f47ad9e6273e643843fd4a14e8", null ],
    [ "wait_for_connection", "structartik__wifi__module.html#a4f0c92a932e7e4b9fb78057eb0ec922d", null ]
];