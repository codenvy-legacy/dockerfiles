var artik__module_8h =
[
    [ "artik_api_version", "structartik__api__version.html", "structartik__api__version" ],
    [ "artik_api_module", "structartik__api__module.html", "structartik__api__module" ],
    [ "MAX_MODULE_NAME", "artik__module_8h.html#add70c9ee93cdc05ed55fd452ea576de8", null ],
    [ "MAX_PLATFORM_NAME", "artik__module_8h.html#a97efe3fd6bc72a892d861c8041d5957b", null ],
    [ "MAX_VERSION_STRING", "artik__module_8h.html#a0083944fec28011c402c42effdd1b0b1", null ],
    [ "artik_module_ops", "artik__module_8h.html#a6494081aa80144dc45d41ea10d264606", null ],
    [ "artik_module_id_t", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424de", [
      [ "ARTIK_MODULE_GPIO", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424deab8a93269151e583591ffcbd8ef8ee5d2", null ],
      [ "ARTIK_MODULE_I2C", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424deabdae218ec0092c8a4bd92cb4aaa2b01b", null ],
      [ "ARTIK_MODULE_SERIAL", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424dea234c6b3349fbd1bd9955565305d65cee", null ],
      [ "ARTIK_MODULE_PWM", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424dea078f34153bb3dff38635d9a52fea6073", null ],
      [ "ARTIK_MODULE_ADC", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424dea4684fbfc89b3f2c0ea98e5ad13bae7c2", null ],
      [ "ARTIK_MODULE_HTTP", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424dea84c36384a12e1cc2549623be6579ca40", null ],
      [ "ARTIK_MODULE_CLOUD", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424dea49da56595ec949ecf78bb3b1a4587a85", null ],
      [ "ARTIK_MODULE_WIFI", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424dea01dd9daae542a2d2be7d7f4f2bb5e153", null ],
      [ "ARTIK_MODULE_MEDIA", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424deabeeff84b9ffe920122cb846bf8284f5c", null ],
      [ "ARTIK_MODULE_TIME", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424dea5a0ce1a27d4e850c793447b3a931095a", null ],
      [ "ARTIK_MODULE_SECURITY", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424dea9b62955c6cad2444d56c81a6174d1c2b", null ],
      [ "ARTIK_MODULE_SPI", "artik__module_8h.html#a94c9d4a58c49eb0afb332071c46424dea1bc2a550e14214c82cf546b608c43f39", null ]
    ] ],
    [ "artik_get_api_module", "artik__module_8h.html#aed29b1d42b5f6323d745340bfe554fd9", null ],
    [ "artik_get_api_version", "artik__module_8h.html#a412245a37446878cbca98a43b83174a3", null ],
    [ "artik_get_available_modules", "artik__module_8h.html#a1398b50c151e3a36879123c577060bdd", null ],
    [ "artik_get_platform", "artik__module_8h.html#a8a80571cae4c952df98faf1b2e102a18", null ],
    [ "artik_get_platform_name", "artik__module_8h.html#a37fd0d50d0bd6a6014380c2aa2f2e46d", null ],
    [ "artik_is_module_available", "artik__module_8h.html#aa25c1a2b432cb7009448764e64e8bbcd", null ]
];