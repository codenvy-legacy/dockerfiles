var structartik__serial__module =
[
    [ "cancel_wait", "structartik__serial__module.html#a087fd34770a936a99c1770d5b5b30720", null ],
    [ "read", "structartik__serial__module.html#a81bcfb1fbe3a582651c8418ef736a4a4", null ],
    [ "release", "structartik__serial__module.html#aa69bbebc3e0245c3700d2a2999b67a9f", null ],
    [ "request", "structartik__serial__module.html#a65d0ec3dcbaef8b01d08c4351a7e7ac4", null ],
    [ "wait_for_data", "structartik__serial__module.html#abf5f981f9097631cb812165a5c07b656", null ],
    [ "write", "structartik__serial__module.html#a177d756cb7897841b21d32e3626de573", null ]
];