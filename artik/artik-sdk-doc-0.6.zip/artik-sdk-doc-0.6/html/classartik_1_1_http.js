var classartik_1_1_http =
[
    [ "Http", "classartik_1_1_http.html#ae7efa071160d0bd016406a8d5c43e012", null ],
    [ "~Http", "classartik_1_1_http.html#a77c8e51194c06efa257af7ce1e7e5f7e", null ],
    [ "del", "classartik_1_1_http.html#a1b6647a5e75a986613e11a94f3c27a2f", null ],
    [ "get", "classartik_1_1_http.html#a82dd84b1508e8f3cc055f6d2993fe225", null ],
    [ "post", "classartik_1_1_http.html#ad95e45594dd8fc33ea3719420935b664", null ],
    [ "put", "classartik_1_1_http.html#a1adbf7eb9d8223b27459b1463c6314c6", null ]
];