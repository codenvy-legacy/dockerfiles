var artik__adc_8h =
[
    [ "artik_adc_config", "structartik__adc__config.html", "structartik__adc__config" ],
    [ "artik_adc_module", "structartik__adc__module.html", "structartik__adc__module" ],
    [ "MAX_NAME_LEN", "artik__adc_8h.html#afd709f201d7643c3909621f620ea648a", null ],
    [ "artik_adc_handle", "artik__adc_8h.html#ae7bb8663cc83bd87d42cfc2466145d7b", null ],
    [ "adc_module", "artik__adc_8h.html#af9d49c038fe078d40d74b96779727cc0", null ]
];