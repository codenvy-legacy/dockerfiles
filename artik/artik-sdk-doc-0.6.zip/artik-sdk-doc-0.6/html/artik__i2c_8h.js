var artik__i2c_8h =
[
    [ "artik_i2c_config", "structartik__i2c__config.html", "structartik__i2c__config" ],
    [ "artik_i2c_module", "structartik__i2c__module.html", "structartik__i2c__module" ],
    [ "artik_i2c_handle", "artik__i2c_8h.html#a4e223cba2794fb138f089eea6dcae46d", null ],
    [ "artik_i2c_id", "artik__i2c_8h.html#a918723eecef058e9ebed8b2b4b69c354", null ],
    [ "artik_i2c_wordsize_t", "artik__i2c_8h.html#a5dc485e71773b4281e07bf2e08c73209", [
      [ "I2C_8BIT", "artik__i2c_8h.html#a5dc485e71773b4281e07bf2e08c73209a480343f9f99513a4c5115a9871e23dcd", null ],
      [ "I2C_16BIT", "artik__i2c_8h.html#a5dc485e71773b4281e07bf2e08c73209a4639eb0eb8a1ff50007c2f6e146297ae", null ],
      [ "I2C_WORDSIZE_INVALID", "artik__i2c_8h.html#a5dc485e71773b4281e07bf2e08c73209a1d718e262e1c33bd4fb1822e2fd3e8f7", null ]
    ] ],
    [ "i2c_module", "artik__i2c_8h.html#ab00fa2b8dcf955f30fac6d4a269b60aa", null ]
];