var artik__platform_8h =
[
    [ "GENERIC", "artik__platform_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba9e022e6380da28dd73210ed34b137c36", null ],
    [ "ARTIK5", "artik__platform_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba81b966b61cee80d5e455ec2627b3e967", null ],
    [ "ARTIK10", "artik__platform_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba9dde5bd06bc18cc114c0666e0e71a418", null ]
];