var dir_54e9cde3f0eb920985cfdedc73b932ac =
[
    [ "artik_a10_platform.h", "artik__a10__platform_8h.html", "artik__a10__platform_8h" ],
    [ "artik_a5_platform.h", "artik__a5__platform_8h.html", "artik__a5__platform_8h" ],
    [ "artik_generic_platform.h", "artik__generic__platform_8h.html", null ]
];