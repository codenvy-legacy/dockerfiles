var classartik_1_1_i2c =
[
    [ "I2c", "classartik_1_1_i2c.html#a19cda1fa91ce069ff6e5e0d2deaf620d", null ],
    [ "~I2c", "classartik_1_1_i2c.html#a2eee963351b051feae450c23f198bb2d", null ],
    [ "read", "classartik_1_1_i2c.html#a2a409892f93456862b5f9287be2e010e", null ],
    [ "read_register", "classartik_1_1_i2c.html#a78064e80f4f5cc7505f57aaef86d9dc7", null ],
    [ "release", "classartik_1_1_i2c.html#aab99b7e816d5591f41de63f199994d79", null ],
    [ "request", "classartik_1_1_i2c.html#a251ee153f140c3fd9e5ec8fe86c0eb48", null ],
    [ "write", "classartik_1_1_i2c.html#a0a46c60fbca8d600859595eaa80183ba", null ],
    [ "write_register", "classartik_1_1_i2c.html#a4ac33a43e40b9643881165fa8be78fe3", null ]
];