var structartik__serial__config =
[
    [ "baudrate", "structartik__serial__config.html#a67a9e9129981b01c78119a1350f31217", null ],
    [ "data", "structartik__serial__config.html#aba40fa8b9914d21fa551ccedc67e0bd7", null ],
    [ "data_user", "structartik__serial__config.html#a538587d2b00ecb9c2954bf3911ee4eab", null ],
    [ "flowctrl", "structartik__serial__config.html#a8563a423015fc0df4b2e5edd32dcdf9c", null ],
    [ "name", "structartik__serial__config.html#ad733146ba87da3e3fceb8cfb4519a9cb", null ],
    [ "parity", "structartik__serial__config.html#a8556b383a038d57e4923c7ce9d7107be", null ],
    [ "port_num", "structartik__serial__config.html#a2b866b47123a899f42e33b995a195d79", null ],
    [ "stop", "structartik__serial__config.html#a7329192d92fd4cd83b03140c389df57c", null ]
];