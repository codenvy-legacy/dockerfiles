var structartik__i2c__module =
[
    [ "read", "structartik__i2c__module.html#ade275015c3ec45c21062369631a53e23", null ],
    [ "read_register", "structartik__i2c__module.html#aa04626c1dc44696c02b4ef2e808561de", null ],
    [ "release", "structartik__i2c__module.html#a174dfb2501de674aacbe15f4eb7eab69", null ],
    [ "request", "structartik__i2c__module.html#a67f9f6aae0790974c34d4c4ffa8e0df8", null ],
    [ "write", "structartik__i2c__module.html#a336c166ac3f0aa00c50476555161176f", null ],
    [ "write_register", "structartik__i2c__module.html#a09bdda878e6f3f05c54e664fa7961fb9", null ]
];