var searchData=
[
  ['websocket',['Websocket',['../classartik_1_1_websocket.html',1,'artik']]],
  ['wifi',['Wifi',['../classartik_1_1_wifi.html',1,'artik']]]
];
