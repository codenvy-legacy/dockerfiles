var searchData=
[
  ['media',['Media',['../classartik_1_1_media.html',1,'artik']]]
];
