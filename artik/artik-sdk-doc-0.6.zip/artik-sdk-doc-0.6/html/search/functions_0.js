var searchData=
[
  ['artik_5fget_5fapi_5fmodule',['artik_get_api_module',['../artik__module_8h.html#aed29b1d42b5f6323d745340bfe554fd9',1,'artik_module.h']]],
  ['artik_5fget_5fapi_5fversion',['artik_get_api_version',['../artik__module_8h.html#a412245a37446878cbca98a43b83174a3',1,'artik_module.h']]],
  ['artik_5fget_5favailable_5fmodules',['artik_get_available_modules',['../artik__module_8h.html#a1398b50c151e3a36879123c577060bdd',1,'artik_module.h']]],
  ['artik_5fget_5fplatform',['artik_get_platform',['../artik__module_8h.html#a8a80571cae4c952df98faf1b2e102a18',1,'artik_module.h']]],
  ['artik_5fget_5fplatform_5fname',['artik_get_platform_name',['../artik__module_8h.html#a37fd0d50d0bd6a6014380c2aa2f2e46d',1,'artik_module.h']]],
  ['artik_5fis_5fmodule_5favailable',['artik_is_module_available',['../artik__module_8h.html#aa25c1a2b432cb7009448764e64e8bbcd',1,'artik_module.h']]]
];
