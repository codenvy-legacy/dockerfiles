var searchData=
[
  ['generic',['GENERIC',['../artik__platform_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba9e022e6380da28dd73210ed34b137c36',1,'artik_platform.h']]]
];
