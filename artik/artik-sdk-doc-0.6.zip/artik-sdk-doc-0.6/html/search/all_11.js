var searchData=
[
  ['version',['version',['../structartik__api__version.html#ad1cc7b62e1b7d6c5f7c20dcf4ebe9fd4',1,'artik_api_version']]]
];
