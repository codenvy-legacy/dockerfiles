var searchData=
[
  ['time',['Time',['../classartik_1_1_time.html',1,'artik']]]
];
