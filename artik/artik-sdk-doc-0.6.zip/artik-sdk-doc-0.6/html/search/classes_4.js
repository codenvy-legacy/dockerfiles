var searchData=
[
  ['i2c',['I2c',['../classartik_1_1_i2c.html',1,'artik']]]
];
