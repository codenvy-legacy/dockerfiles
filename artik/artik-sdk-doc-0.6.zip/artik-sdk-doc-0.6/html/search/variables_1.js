var searchData=
[
  ['baudrate',['baudrate',['../structartik__serial__config.html#a67a9e9129981b01c78119a1350f31217',1,'artik_serial_config']]],
  ['bits_5fper_5fword',['bits_per_word',['../structartik__spi__config.html#af1190f588e95af931b7872016f6911a1',1,'artik_spi_config']]],
  ['bssid',['bssid',['../structartik__wifi__ap.html#a4af7d378261c8071d48e794d01c70b82',1,'artik_wifi_ap']]],
  ['bus',['bus',['../structartik__spi__config.html#ae86c1db146fb82f89cf330d546ccacfc',1,'artik_spi_config']]]
];
