var searchData=
[
  ['major',['major',['../structartik__api__version.html#a7567d8c63bd8f9b882264eb6fef5ca89',1,'artik_api_version']]],
  ['max_5fspeed',['max_speed',['../structartik__spi__config.html#a2f151071f4a33c82ba1c9fffdbd7cdd2',1,'artik_spi_config']]],
  ['minor',['minor',['../structartik__api__version.html#ac35ba53b944a9f233a44dd5287a190b4',1,'artik_api_version']]],
  ['mode',['mode',['../structartik__spi__config.html#a7ef45bc882a459107765c2de0db56aef',1,'artik_spi_config']]]
];
