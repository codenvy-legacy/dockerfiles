var searchData=
[
  ['cancel_5falarm',['cancel_alarm',['../structartik__time__module.html#a488e8c3a988d8248e9d4fd3915f3ce25',1,'artik_time_module']]],
  ['cancel_5fwait',['cancel_wait',['../structartik__gpio__module.html#a5a0940ed2d118adb0e48236ab0db95d6',1,'artik_gpio_module::cancel_wait()'],['../structartik__serial__module.html#a087fd34770a936a99c1770d5b5b30720',1,'artik_serial_module::cancel_wait()']]],
  ['connect',['connect',['../structartik__wifi__module.html#a5ec232bfaba35f470708d432580c999e',1,'artik_wifi_module']]],
  ['create_5falarm_5fdate',['create_alarm_date',['../structartik__time__module.html#aeb928b88b023413e5491a9b30739d94f',1,'artik_time_module']]],
  ['create_5falarm_5fsecond',['create_alarm_second',['../structartik__time__module.html#a13a247b58642f800438f4310e48a35c7',1,'artik_time_module']]],
  ['cs',['cs',['../structartik__spi__config.html#a56700c68549e789696a20f0d4f485070',1,'artik_spi_config']]]
];
