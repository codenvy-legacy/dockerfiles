var searchData=
[
  ['artik_5ftime_5fdformat',['ARTIK_TIME_DFORMAT',['../artik__time_8h.html#afe984d83e132443d98e7b5167231e5df',1,'artik_time.h']]]
];
