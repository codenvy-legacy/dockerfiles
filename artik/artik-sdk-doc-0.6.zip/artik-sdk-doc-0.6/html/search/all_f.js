var searchData=
[
  ['time',['Time',['../classartik_1_1_time.html',1,'artik']]],
  ['type',['type',['../structartik__gpio__config.html#a4864c64fb7b031f181f0b0f3725e6b0b',1,'artik_gpio_config']]]
];
