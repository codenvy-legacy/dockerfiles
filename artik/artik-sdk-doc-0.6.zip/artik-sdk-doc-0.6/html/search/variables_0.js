var searchData=
[
  ['address',['address',['../structartik__i2c__config.html#a29cf7ef5a5e94e45fb26fa0a4b4ff674',1,'artik_i2c_config']]]
];
