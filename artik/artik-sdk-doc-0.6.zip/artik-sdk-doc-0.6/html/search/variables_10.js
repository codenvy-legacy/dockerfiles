var searchData=
[
  ['update_5fdevice_5ftoken',['update_device_token',['../structartik__cloud__module.html#abe9dc49377aa69af886d85669f127cd5',1,'artik_cloud_module']]],
  ['uri',['uri',['../structartik__websocket__config.html#ae2705f2dfa53cf7b2b5d23f1c70d3b61',1,'artik_websocket_config']]],
  ['user_5fdata',['user_data',['../structartik__adc__config.html#ac6c9af31f17aec387142a617cd3d99be',1,'artik_adc_config::user_data()'],['../structartik__gpio__config.html#ae152f14657060fe522c059907c082956',1,'artik_gpio_config::user_data()'],['../structartik__pwm__config.html#a360ddbee67f8253b8f6f552d9206e210',1,'artik_pwm_config::user_data()']]]
];
