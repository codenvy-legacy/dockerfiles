var searchData=
[
  ['host',['host',['../structartik__websocket__config.html#ace12952ab3e5b3aed0c6d4fc857be7d2',1,'artik_websocket_config']]],
  ['http',['Http',['../classartik_1_1_http.html',1,'artik']]]
];
