var searchData=
[
  ['artik10',['ARTIK10',['../artik__platform_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba9dde5bd06bc18cc114c0666e0e71a418',1,'artik_platform.h']]],
  ['artik5',['ARTIK5',['../artik__platform_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba81b966b61cee80d5e455ec2627b3e967',1,'artik_platform.h']]]
];
