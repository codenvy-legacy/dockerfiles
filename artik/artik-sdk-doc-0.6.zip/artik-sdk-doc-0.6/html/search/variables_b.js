var searchData=
[
  ['ops',['ops',['../structartik__api__module.html#af30ebd859b83f906bfd0201e9f0301ab',1,'artik_api_module']]]
];
