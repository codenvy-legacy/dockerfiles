var structartik__websocket__config =
[
    [ "host", "structartik__websocket__config.html#ace12952ab3e5b3aed0c6d4fc857be7d2", null ],
    [ "interface", "structartik__websocket__config.html#a5ed291993ce54e9ac27a7ae2b0661db2", null ],
    [ "port", "structartik__websocket__config.html#a599ffbc8fd9f9d5973d8634c813c61f7", null ],
    [ "ssl_connection", "structartik__websocket__config.html#a231f2d29247c29f2a957050a8945ec87", null ],
    [ "uri", "structartik__websocket__config.html#ae2705f2dfa53cf7b2b5d23f1c70d3b61", null ]
];