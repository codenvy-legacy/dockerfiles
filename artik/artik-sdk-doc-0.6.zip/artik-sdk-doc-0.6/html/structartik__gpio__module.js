var structartik__gpio__module =
[
    [ "cancel_wait", "structartik__gpio__module.html#a5a0940ed2d118adb0e48236ab0db95d6", null ],
    [ "get_direction", "structartik__gpio__module.html#a96900915f823deba0bcc71ab8a3078e7", null ],
    [ "get_id", "structartik__gpio__module.html#aba3290681b96f40321af6b701cfd5530", null ],
    [ "get_name", "structartik__gpio__module.html#ae834fb4c5843138b8cce795305e2c994", null ],
    [ "get_type", "structartik__gpio__module.html#afb120c8547f993e8527749a3470c4ab7", null ],
    [ "read", "structartik__gpio__module.html#a08ad7b16e8911296fe6cf60f459cb0c2", null ],
    [ "release", "structartik__gpio__module.html#af919ae359fa0d815d97b887ec6e1ec4d", null ],
    [ "request", "structartik__gpio__module.html#a92bc5a872e246f0dcf1f36f1b45e4163", null ],
    [ "wait_for_change", "structartik__gpio__module.html#a5cbde277193e30b841085a95b1717bf0", null ],
    [ "write", "structartik__gpio__module.html#a021095f5146276045629c63eb39ade99", null ]
];