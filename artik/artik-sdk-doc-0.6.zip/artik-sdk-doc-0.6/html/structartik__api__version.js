var structartik__api__version =
[
    [ "major", "structartik__api__version.html#a7567d8c63bd8f9b882264eb6fef5ca89", null ],
    [ "minor", "structartik__api__version.html#ac35ba53b944a9f233a44dd5287a190b4", null ],
    [ "version", "structartik__api__version.html#ad1cc7b62e1b7d6c5f7c20dcf4ebe9fd4", null ]
];