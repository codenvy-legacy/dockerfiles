var artik__serial_8h =
[
    [ "artik_serial_config", "structartik__serial__config.html", "structartik__serial__config" ],
    [ "artik_serial_module", "structartik__serial__module.html", "structartik__serial__module" ],
    [ "MAX_NAME_LEN", "artik__serial_8h.html#afd709f201d7643c3909621f620ea648a", null ],
    [ "artik_serial_handle", "artik__serial_8h.html#ae70266065f93a38dbe95e5f38e769f09", null ],
    [ "artik_serial_baudrate_t", "artik__serial_8h.html#af5712e6e6cd1d71c4fe38ad8818fd3ef", [
      [ "ARTIK_SERIAL_BAUD_4800", "artik__serial_8h.html#af5712e6e6cd1d71c4fe38ad8818fd3efa6e382cac4c7a67bb9885effa69afd46b", null ],
      [ "ARTIK_SERIAL_BAUD_9600", "artik__serial_8h.html#af5712e6e6cd1d71c4fe38ad8818fd3efaa79778950c587638cb646674e19a48c5", null ],
      [ "ARTIK_SERIAL_BAUD_14400", "artik__serial_8h.html#af5712e6e6cd1d71c4fe38ad8818fd3efa43667524226303beed448b62504bcd74", null ],
      [ "ARTIK_SERIAL_BAUD_19200", "artik__serial_8h.html#af5712e6e6cd1d71c4fe38ad8818fd3efa347821da05ca105385432b3dd629023d", null ],
      [ "ARTIK_SERIAL_BAUD_38400", "artik__serial_8h.html#af5712e6e6cd1d71c4fe38ad8818fd3efa83a909ef9f9748e009d04320098ae206", null ],
      [ "ARTIK_SERIAL_BAUD_57600", "artik__serial_8h.html#af5712e6e6cd1d71c4fe38ad8818fd3efa2722c5f1daeed8c975d076c789a9cb44", null ],
      [ "ARTIK_SERIAL_BAUD_115200", "artik__serial_8h.html#af5712e6e6cd1d71c4fe38ad8818fd3efa38da984fc070cd87a0b579c952fab0f6", null ]
    ] ],
    [ "artik_serial_data_t", "artik__serial_8h.html#a7b1372e920ff949c7333c63d9d1cfeb7", [
      [ "ARTIK_SERIAL_DATA_7BIT", "artik__serial_8h.html#a7b1372e920ff949c7333c63d9d1cfeb7a099efda2e3340f873271d540c305b738", null ],
      [ "ARTIK_SERIAL_DATA_8BIT", "artik__serial_8h.html#a7b1372e920ff949c7333c63d9d1cfeb7aac5ec830f7f80b1c1791422fc035981b", null ]
    ] ],
    [ "artik_serial_flowcontrol_t", "artik__serial_8h.html#a7631c8da3a363f8889b230da7902c27a", [
      [ "ARTIK_SERIAL_FLOWCTRL_NONE", "artik__serial_8h.html#a7631c8da3a363f8889b230da7902c27aadcbd539dd022f2740133796f098b9831", null ],
      [ "ARTIK_SERIAL_FLOWCTRL_HARD", "artik__serial_8h.html#a7631c8da3a363f8889b230da7902c27aafdd672ceada2c0f87bceb4d4fe263140", null ],
      [ "ARTIK_SERIAL_FLOWCTRL_SOFT", "artik__serial_8h.html#a7631c8da3a363f8889b230da7902c27aaab9f04f7463dc1751129bd23abd4c1c7", null ]
    ] ],
    [ "artik_serial_parity_t", "artik__serial_8h.html#a5a024e93ee5f985bb0de216d4762ae04", [
      [ "ARTIK_SERIAL_PARITY_NONE", "artik__serial_8h.html#a5a024e93ee5f985bb0de216d4762ae04a5b8041e5b57b21e40c4e570e6d34773a", null ],
      [ "ARTIK_SERIAL_PARITY_ODD", "artik__serial_8h.html#a5a024e93ee5f985bb0de216d4762ae04a3bd8df6345f3090bfc947d79a743ae63", null ],
      [ "ARTIK_SERIAL_PARITY_EVEN", "artik__serial_8h.html#a5a024e93ee5f985bb0de216d4762ae04a840dcb8fb5fd82c0592c0e0fe1490327", null ]
    ] ],
    [ "artik_serial_stop_t", "artik__serial_8h.html#a6d5f9f1c796df1e8945ae675ebd29fb9", [
      [ "ARTIK_SERIAL_STOP_1BIT", "artik__serial_8h.html#a6d5f9f1c796df1e8945ae675ebd29fb9ab099d55dc7f8c1a62a8a621016da92b0", null ],
      [ "ARTIK_SERIAL_STOP_2BIT", "artik__serial_8h.html#a6d5f9f1c796df1e8945ae675ebd29fb9a82c84922a88d9d634d9b9f66192df118", null ]
    ] ],
    [ "serial_module", "artik__serial_8h.html#ab85a57baf3a6750b237a04b4d3f33f00", null ]
];