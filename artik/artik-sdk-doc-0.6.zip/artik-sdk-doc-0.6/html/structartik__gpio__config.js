var structartik__gpio__config =
[
    [ "dir", "structartik__gpio__config.html#a740709c26e63234378bea90652fd9990", null ],
    [ "edge", "structartik__gpio__config.html#afc2243e4543a2a85fd5ff8530476447c", null ],
    [ "id", "structartik__gpio__config.html#a0fa9857159d58a44dc6a89eaf6456986", null ],
    [ "initial_value", "structartik__gpio__config.html#aeb4f223092fa62befda128903cc5f6e3", null ],
    [ "name", "structartik__gpio__config.html#aec851784de416d597895a301b7a0f22e", null ],
    [ "type", "structartik__gpio__config.html#a4864c64fb7b031f181f0b0f3725e6b0b", null ],
    [ "user_data", "structartik__gpio__config.html#ae152f14657060fe522c059907c082956", null ]
];